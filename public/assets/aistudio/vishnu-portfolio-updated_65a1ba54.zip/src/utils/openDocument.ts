import { IDB_PREFIX, getStoredDocument } from './documentStore';

const download = (blob: Blob, name: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
};

// Opens an uploaded document.
// PDFs and images open in a new tab; ZIP and RAR archives are downloaded.
// Supports files saved in the browser's IndexedDB ("idb:<id>") and older data URLs.
export const openDocument = async (ref: string) => {
  try {
    let blob: Blob;
    let name = 'document';

    if (ref.startsWith(IDB_PREFIX)) {
      const rec = await getStoredDocument(ref);
      if (!rec) {
        alert('This document is no longer available in this browser. Please upload it again from the admin panel.');
        return;
      }
      blob = rec.blob.type === rec.type ? rec.blob : new Blob([rec.blob], { type: rec.type });
      name = rec.name;
    } else {
      blob = await (await fetch(ref)).blob();
    }

    if (blob.type === 'application/pdf' || blob.type.startsWith('image/')) {
      const url = URL.createObjectURL(blob);
      const win = window.open(url, '_blank');
      if (!win) window.location.href = url;
    } else {
      download(blob, name);
    }
  } catch {
    /* ignore */
  }
};
