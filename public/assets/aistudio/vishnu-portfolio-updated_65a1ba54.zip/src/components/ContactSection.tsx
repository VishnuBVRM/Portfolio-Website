import React from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import {
  Mail,
  Phone,
  Linkedin,
  Github,
  MessageCircle,
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { profile } = usePortfolio();

  // WhatsApp needs the number in international format, digits only
  const whatsappNumber = (profile.whatsapp || profile.phone).replace(/\D/g, '');
  const phoneNumber = profile.phone.replace(/\D/g, '');

  const contactItems = [
    {
      label: 'Gmail',
      href: `mailto:${profile.email}`,
      icon: Mail,
      external: false,
    },
    {
      label: 'Mobile',
      href: `tel:+${phoneNumber}`,
      icon: Phone,
      external: false,
    },
    {
      label: 'WhatsApp',
      href: `https://wa.me/${whatsappNumber}`,
      icon: MessageCircle,
      external: true,
    },
    {
      label: 'LinkedIn',
      href: profile.linkedinUrl,
      icon: Linkedin,
      external: true,
    },
    {
      label: 'GitHub',
      href: profile.githubUrl,
      icon: Github,
      external: true,
    },
  ];

  return (
    <section id="contact" className="py-20 relative">
      <span id="hire-me" className="absolute -top-20" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="max-w-md mx-auto">
          
          {/* Left Column: Hiring Preferences & Direct Channels (5 cols) */}
          <div className="space-y-6">
            
            {/* Contact Details Card */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 space-y-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Mail className="w-4 h-4 text-cyan-400" />
                <span>Contact Details</span>
              </h4>
              <div className="flex flex-wrap items-center justify-center gap-4 pt-1">
                {contactItems.map((item) => (
                  <a
                    key={item.label}
                    href={item.href}
                    {...(item.external ? { target: '_blank', rel: 'noreferrer' } : {})}
                    title={item.label}
                    aria-label={item.label}
                    className="w-12 h-12 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-cyan-400 hover:text-white hover:bg-indigo-600 hover:border-indigo-500 transition shadow-lg"
                  >
                    <item.icon className="w-5 h-5" />
                  </a>
                ))}
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
