import React from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import overviewBg from '../assets/overview-bg.jpg';
import profilePhoto from '../assets/vishnu.png';
import {
  FileText,
  MapPin,
  Clock,
  Sparkles,
  Database,
  Cpu,
  Layers,
  Zap,
  Edit2,
  ShieldCheck,
  Phone,
  Download
} from 'lucide-react';

export const Hero: React.FC = () => {
  const {
    profile,
    setIsResumeModalOpen,
    liveEditMode,
    setQuickEditTarget
  } = usePortfolio();

  return (
    <section id="overview" className="relative isolate pt-12 pb-20 md:pt-20 md:pb-28 overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 -z-20 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${overviewBg})` }}
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-slate-950/70 via-slate-950/60 to-slate-950 pointer-events-none" />

      {/* Background Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-indigo-600/15 via-cyan-500/10 to-transparent blur-3xl pointer-events-none rounded-full -z-10" />
      <div className="absolute -top-10 -right-20 w-96 h-96 bg-indigo-500/10 blur-3xl pointer-events-none rounded-full -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
        <div className="lg:col-span-7 space-y-6">
          
          {/* Availability Badge & Role Tag */}
          <div className="flex flex-wrap items-center gap-3">
              {liveEditMode && (
                <button
                  onClick={() => setQuickEditTarget({ type: 'profile' })}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30"
                >
                  <Edit2 className="w-3 h-3" />
                  Edit Bio
                </button>
              )}
            </div>

            {/* Name & Title */}
            <div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1]">
                Hi, I'm <span className="bg-gradient-to-r from-indigo-400 via-sky-300 to-cyan-300 bg-clip-text text-transparent">{profile.name}</span>
              </h1>
              <p className="text-xl sm:text-2xl font-semibold text-slate-300 mt-3 font-mono">
                {profile.title}
              </p>
            </div>

            {/* Core Stack Pill Ribbon */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-xs">
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/50 transition">
                <span className="text-slate-400 block text-[10px] uppercase font-sans">Frontend</span>
                <span className="font-bold text-sky-400">Angular (MEAN Stack)</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/50 transition">
                <span className="text-slate-400 block text-[10px] uppercase font-sans">Backend Core</span>
                <span className="font-bold text-emerald-400">Java & Spring Boot 4.1.1</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/50 transition">
                <span className="text-slate-400 block text-[10px] uppercase font-sans">Database</span>
                <span className="font-bold text-amber-400">MySQL & MongoDB</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/50 transition">
                <span className="text-slate-400 block text-[10px] uppercase font-sans">Network & Security</span>
                <span className="font-bold text-indigo-400">Cisco CCNA & VPN</span>
              </div>
            </div>

            {/* Bio text */}
            <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
              {profile.bio}
            </p>

            {/* Quick Meta Info from Resume */}
            <div className="flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-400 pt-1">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-indigo-400" />
                <span>{profile.location}</span>
              </div>
              <div className="flex items-center gap-1.5 text-indigo-300">
                <Phone className="w-4 h-4 text-cyan-400" />
                <span>{profile.phone}</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <ShieldCheck className="w-4 h-4" />
                <span>Certified: Capgemini Java Full Stack & CCNA</span>
              </div>
            </div>

            {/* Call To Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-3">
              {profile.resumePdfUrl && (
                <a
                  href={profile.resumePdfUrl}
                  download="VISHNU_VARDHAN_CHINTALA_Resume.pdf"
                  className="flex items-center gap-2 px-4 py-3 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 font-semibold text-sm transition"
                >
                  <Download className="w-4 h-4" />
                  <span>Download PDF Resume</span>
                </a>
              )}
            </div>

        </div>

        {/* Profile Photo (right side) */}
        <div className="lg:col-span-5 flex justify-center lg:justify-end">
          <div className="relative">
            <div className="absolute -inset-3 rounded-3xl bg-gradient-to-tr from-indigo-500/40 via-cyan-400/30 to-transparent blur-2xl" />
            <img
              src={profilePhoto}
              alt={profile.name}
              className="relative w-64 sm:w-72 lg:w-80 xl:w-96 aspect-[4/5] object-cover object-top rounded-3xl border border-slate-700/80 shadow-2xl shadow-indigo-950/50"
            />
          </div>
        </div>

        </div>
      </div>
    </section>
  );
};
