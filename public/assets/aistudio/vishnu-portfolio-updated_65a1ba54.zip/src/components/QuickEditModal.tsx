import React, { useState, useEffect } from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { X, Save, Edit2 } from 'lucide-react';

export const QuickEditModal: React.FC = () => {
  const {
    quickEditTarget,
    setQuickEditTarget,
    projects,
    updateProject,
    skills,
    updateSkill,
    experience,
    updateExperience,
    education,
    updateEducation,
    profile,
    updateProfile
  } = usePortfolio();

  const [formData, setFormData] = useState<any>({});

  useEffect(() => {
    if (!quickEditTarget) return;

    if (quickEditTarget.type === 'profile') {
      setFormData({
        title: profile.title,
        bio: profile.bio,
        location: profile.location,
        salaryExpectation: profile.salaryExpectation,
      });
    } else if (quickEditTarget.type === 'project' && quickEditTarget.id) {
      const p = projects.find((proj) => proj.id === quickEditTarget.id);
      if (p) {
        setFormData({
          title: p.title,
          subtitle: p.subtitle,
          frontend: p.coreStack.frontend,
          backend: p.coreStack.backend,
          database: p.coreStack.database,
          metric1: p.metrics[0] || '',
          metric2: p.metrics[1] || '',
          problemSolved: p.problemSolved,
        });
      }
    } else if (quickEditTarget.type === 'skill' && quickEditTarget.id) {
      const s = skills.find((sk) => sk.id === quickEditTarget.id);
      if (s) {
        setFormData({
          name: s.name,
          proficiency: s.proficiency,
          years: s.years,
          description: s.description,
        });
      }
    } else if (quickEditTarget.type === 'experience' && quickEditTarget.id) {
      const e = experience.find((exp) => exp.id === quickEditTarget.id);
      if (e) {
        setFormData({
          role: e.role,
          company: e.company,
          startDate: e.startDate,
          endDate: e.endDate,
          keyMetric: e.keyMetric || '',
          description: e.description,
        });
      }
    } else if (quickEditTarget.type === 'education' && quickEditTarget.id) {
      const ed = education.find((item) => item.id === quickEditTarget.id);
      if (ed) {
        setFormData({
          degree: ed.degree,
          field: ed.field || '',
          institution: ed.institution,
          location: ed.location || '',
          year: ed.year,
          score: ed.score || '',
          honors: ed.honors || ''
        });
      }
    }
  }, [quickEditTarget, projects, skills, experience, education, profile]);

  if (!quickEditTarget) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (quickEditTarget.type === 'profile') {
      updateProfile({
        title: formData.title,
        bio: formData.bio,
        location: formData.location,
        salaryExpectation: formData.salaryExpectation,
      });
    } else if (quickEditTarget.type === 'project' && quickEditTarget.id) {
      const orig = projects.find((p) => p.id === quickEditTarget.id);
      if (orig) {
        updateProject(quickEditTarget.id, {
          title: formData.title,
          subtitle: formData.subtitle,
          problemSolved: formData.problemSolved,
          coreStack: {
            ...orig.coreStack,
            frontend: formData.frontend,
            backend: formData.backend,
            database: formData.database,
          },
          metrics: [formData.metric1, formData.metric2, ...orig.metrics.slice(2)].filter(Boolean),
        });
      }
    } else if (quickEditTarget.type === 'skill' && quickEditTarget.id) {
      updateSkill(quickEditTarget.id, {
        name: formData.name,
        proficiency: Number(formData.proficiency),
        years: Number(formData.years),
        description: formData.description,
      });
    } else if (quickEditTarget.type === 'experience' && quickEditTarget.id) {
      updateExperience(quickEditTarget.id, {
        role: formData.role,
        company: formData.company,
        startDate: formData.startDate,
        endDate: formData.endDate,
        keyMetric: formData.keyMetric,
        description: formData.description,
      });
    } else if (quickEditTarget.type === 'education' && quickEditTarget.id) {
      updateEducation(quickEditTarget.id, {
        degree: formData.degree,
        field: formData.field,
        institution: formData.institution,
        location: formData.location,
        year: formData.year,
        score: formData.score,
        honors: formData.honors
      });
    }

    setQuickEditTarget(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md no-print">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        <button
          onClick={() => setQuickEditTarget(null)}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4 border-b border-slate-800 pb-3">
          <Edit2 className="w-4 h-4 text-amber-400" />
          <h3 className="font-bold text-white text-base capitalize">
            Quick In-Place Edit ({quickEditTarget.type})
          </h3>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          {quickEditTarget.type === 'profile' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Headline Title</label>
                <input
                  type="text"
                  value={formData.title || ''}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Bio / Executive Summary</label>
                <textarea
                  rows={3}
                  value={formData.bio || ''}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs resize-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Location</label>
                  <input
                    type="text"
                    value={formData.location || ''}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Salary Expectation</label>
                  <input
                    type="text"
                    value={formData.salaryExpectation || ''}
                    onChange={(e) => setFormData({ ...formData, salaryExpectation: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
              </div>
            </>
          )}

          {quickEditTarget.type === 'project' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Project Title</label>
                <input
                  type="text"
                  value={formData.title || ''}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Subtitle</label>
                <input
                  type="text"
                  value={formData.subtitle || ''}
                  onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Frontend</label>
                  <input
                    type="text"
                    value={formData.frontend || ''}
                    onChange={(e) => setFormData({ ...formData, frontend: e.target.value })}
                    className="w-full px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Backend</label>
                  <input
                    type="text"
                    value={formData.backend || ''}
                    onChange={(e) => setFormData({ ...formData, backend: e.target.value })}
                    className="w-full px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Database</label>
                  <input
                    type="text"
                    value={formData.database || ''}
                    onChange={(e) => setFormData({ ...formData, database: e.target.value })}
                    className="w-full px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Metric 1</label>
                  <input
                    type="text"
                    value={formData.metric1 || ''}
                    onChange={(e) => setFormData({ ...formData, metric1: e.target.value })}
                    className="w-full px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Metric 2</label>
                  <input
                    type="text"
                    value={formData.metric2 || ''}
                    onChange={(e) => setFormData({ ...formData, metric2: e.target.value })}
                    className="w-full px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                  />
                </div>
              </div>
            </>
          )}

          {quickEditTarget.type === 'skill' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Skill Name</label>
                <input
                  type="text"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Proficiency: {formData.proficiency}%
                  </label>
                  <input
                    type="range"
                    min="50"
                    max="100"
                    value={formData.proficiency || 90}
                    onChange={(e) => setFormData({ ...formData, proficiency: e.target.value })}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Years Experience</label>
                  <input
                    type="number"
                    value={formData.years || 5}
                    onChange={(e) => setFormData({ ...formData, years: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
                <input
                  type="text"
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>
            </>
          )}

          {quickEditTarget.type === 'experience' && (
            <>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Role</label>
                  <input
                    type="text"
                    value={formData.role || ''}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Company</label>
                  <input
                    type="text"
                    value={formData.company || ''}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Key Metric</label>
                <input
                  type="text"
                  value={formData.keyMetric || ''}
                  onChange={(e) => setFormData({ ...formData, keyMetric: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>
            </>
          )}

          {quickEditTarget.type === 'education' && (
            <>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Degree / Qualification</label>
                  <input
                    type="text"
                    required
                    value={formData.degree || ''}
                    onChange={(e) => setFormData({ ...formData, degree: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Major / Field</label>
                  <input
                    type="text"
                    value={formData.field || ''}
                    onChange={(e) => setFormData({ ...formData, field: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Institution / School / College</label>
                <input
                  type="text"
                  required
                  value={formData.institution || ''}
                  onChange={(e) => setFormData({ ...formData, institution: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Location</label>
                  <input
                    type="text"
                    value={formData.location || ''}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Years / Duration</label>
                  <input
                    type="text"
                    value={formData.year || ''}
                    onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                    className="w-full px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Score / CGPA</label>
                  <input
                    type="text"
                    value={formData.score || ''}
                    onChange={(e) => setFormData({ ...formData, score: e.target.value })}
                    className="w-full px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Board / University / Honors</label>
                <input
                  type="text"
                  value={formData.honors || ''}
                  onChange={(e) => setFormData({ ...formData, honors: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-white text-xs"
                />
              </div>
            </>
          )}

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setQuickEditTarget(null)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
